#!/bin/bash


VERSION="2.0.3"
SCRIPTNAME="$(basename $0)"

ECHO="/bin/echo -e"
OKColor='\033[92m'
FAILColor='\033[91m'
SKIPColor='\033[93m'
GREYColor='\033[0,37m'
ENDColor='\033[0m'

SCRIPTDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
MACHINES="$(realpath ~/MACHINES)"
ALL=""
ERRORCODES=""

request_log="/tmp/kpi_reqlog.out"
get_log="/tmp/kpi_getlog.out"
put_log="/tmp/kpi_putlog.out"
delete_log="/tmp/kpi_deletelog.out"
head_log="/tmp/kpi_headlog.out"

RemoteCmdSetup='
request_log="/tmp/kpi_reqlog.out"
get_log="/tmp/kpi_getlog.out"
put_log="/tmp/kpi_putlog.out"
delete_log="/tmp/kpi_deletelog.out"
head_log="/tmp/kpi_headlog.out"

nodeIP="$(hostname -i)"
'



function usage
{
  $ECHO "Usage:  $SCRIPTNAME -n <# hours> -min <# minutes> [ -topnum <# lines> ] [ -m <machines file> ]"
  $ECHO "                         [ -all ] |"
  $ECHO "                         [ -summary ] [ -latency ] [ -top ]"
  $ECHO ""
  $ECHO "Options:"
  $ECHO "\t-h: Help                - This help screen"
  $ECHO
  $ECHO "\t-n <# hours>            - Number of hours of history to display"
  $ECHO "\t                          (1 - 240)"
  $ECHO "\t-min <# minutes>        - Number of minutes of history to display"
  $ECHO "\t                          Can be used standalone or with -n option"
  $ECHO "\t                          (1 - 60)"
  $ECHO "\t-topnum <# lines>       - Number of top URLs and hosts to display"
  $ECHO "\t                          (default: 10  max:1000)"
  $ECHO ""
  $ECHO "\t-m: Machines file       - Name and location of machines file to use"
  $ECHO "\t                          (default: '~/MACHINES')"
  $ECHO ""
  $ECHO "\t-all: all data          - Show all KPI tables (default)"
  $ECHO ""
  $ECHO "\t-summary                - Show request count and error count table"
  $ECHO "\t-size                   - Show request size table"
  $ECHO "\t-latency                - Show request latency tables"
  $ECHO "\t-top                    - Show top request and top talkers"
  $ECHO ""
  $ECHO "\t-errorcode <all|number> - which HTTP error codes to check for.  <number> is "
  $ECHO "\t                          the HTTP error code, e.g. 404, 500, 503, etc."
  $ECHO "\t                          'all' shows all error types."
  $ECHO "\t                          This option can be specified multiple times for multiple codes"
  $ECHO "\t                          (default: 500)"
  $ECHO ""


  exit 1

}


function parse_args
{

	if [[ $# -lt 1 ]]; then
		echo "No arguments specified"
		usage
	fi

	while [ -n "$1" ]
	do
		case $1 in
		"" )
			;;
        "-h" )
            usage
            ;;
		"-n" )
			NUMHOURS="$2"

			if [[ $NUMHOURS -lt 1 || $NUMHOURS -gt 240 ]]; then
				echo "ERROR:  Invalid number of hours.  1 to 240 hours supported."
				exit 1
			fi

			shift 2
			;;
		"-min" )
			NUMMINS="$2"

			if [[ $NUMMINS -lt 1 || $NUMMINS -gt 60 ]]; then
				echo "ERROR:  Invalid number of minutes.  1 to 60 supported."
				exit 1
			fi

			shift 2
			;;
		"-topnum" )
			NUMTOP="$2"

			if [[ $NUMTOP -lt 1 || $NUMTOP -gt 1000 ]]; then
				echo "ERROR:  Invalid number of minutes.  1 to 1000 supported."
				exit 1
			fi

			shift 2
			;;
		"-m" )
			MACHINES="$2"

			if [[ ! -f "$MACHINES" ]]; then
				echo "ERROR:  No file named '$MACHINES' exists"
				exit 1
			fi
			shift 2
			;;
		"-all" )

			ALL="true"

			shift 1
			;;
		"-summary" )

			SUMMARY="true"

			if [[ "$ALL" == "" ]]; then
				ALL="false"
			fi

			shift 1
			;;
		"-sizes" )

			SIZES="true"

			if [[ "$ALL" == "" ]]; then
				ALL="false"
			fi

			shift 1
			;;
		"-latency" )

			LATENCY="true"

			if [[ "$ALL" == "" ]]; then
				ALL="false"
			fi

			shift 1
			;;
		"-top" )

			TOP="true"

			if [[ "$ALL" == "" ]]; then
				ALL="false"
			fi

			shift 1
			;;
		"-errorcode" )

			if [[ "$(echo "$2" | tr '[:upper:]' '[:lower:]')" == "all" ]]; then
				ERRORCODES="500 503 404 403 400"
			else
				ERRORCODES="$ERRORCODES $2"
			fi

			shift 2
			;;


        *)
			echo "ERROR:  Invalid option '${1}'"
			echo ""
            usage
            ;;
		esac
	done # Loop through parameters


	if [[ "$NUMMINS" == "" && "$NUMHOURS" == "" ]]; then
		echo "ERROR:  Timeframe must be specified with -n and/or -min"
		exit 1
	else
		if [[ "$NUMMINS" == "" ]]; then
			NUMMINS=0
		fi
		if [[ "$NUMHOURS" == "" ]]; then
			NUMHOURS=0
		fi
	fi




	if [[ "$ALL" == "" ]]; then
		ALL="true"
	fi

	if [[ "$ERRORCODES" == "" ]];then
		ERRORCODES="500"
	fi
	if [[ "$NUMTOP" == "" ]];then
		NUMTOP="10"
	fi

	RemoteCmdSetup="$RemoteCmdSetup\
	ERRORCODES=\"$ERRORCODES\" \
	"


}

function printDone() {
	echo -e "${OKColor}DONE${ENDColor}"
}

function printFail() {
	echo -e "${FAILColor}FAILED${ENDColor}"
}

function printSkip() {
	if [[ $1 -eq 1 ]]; then # Don't print a newline
		echo -n -e "${SKIPColor}SKIPPED${ENDColor}"
	else
		echo -e "${SKIPColor}SKIPPED${ENDColor}"
	fi
}


# -------------------- Worker functions --------------------

function collect_data () {
	echo -n "Extracting RequestLog data for the last $NUMHOURS hour(s) and $NUMMINS minute(s)..."

	TODAYS_DATE="$(date +%Y-%m-%d)"

	(( MINUTESAGO=NUMHOURS*60+NUMMINS ))

	(( DAYSHISTORY=($MINUTESAGO-1)/1440 + 1 ))

	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "FILES=\"\$(find /var/log -name dataheadsvc.log* -mtime -${DAYSHISTORY} )\"; echo \$FILES; zgrep -h RequestLog \$FILES |  awk -v d=\"\$(date -d'$MINUTESAGO minutes ago' +'%FT%T,000')\" '\$1>=d &&/RequestLog/' > $request_log" > /dev/null

	printDone

	echo -n "Preprocessing data..."


	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "grep -w 'GET' $request_log > $get_log" >/dev/null
	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "grep -w 'HEAD' $request_log > $head_log" >/dev/null
	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "grep -w 'PUT' $request_log > $put_log" >/dev/null
	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "grep -w 'DELETE' $request_log > $delete_log" >/dev/null

	printDone

 }




print_requests() {

	RequestsHeader1="                           All Requests               "
	RequestsHeader2="Node             GETs      PUTs      DELETEs  HEADs   Total"
	for ErrorCode in $ERRORCODES; do
		RequestsHeader1="${RequestsHeader1}                   ${ErrorCode} Errors                  "
		RequestsHeader2="${RequestsHeader2}     GETs    PUTs    DELETEs  HEADs   Total"
	done

	echo "$RequestsHeader1"
	echo "$RequestsHeader2"

	#echo "                           All Requests                              500 Errors                  "
	#echo "Node              GETs   PUTs   DELETEs  HEADs   Total    GETs   PUTs   DELETEs  HEADs   Total"



	RequestData="$(${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "$RemoteCmdSetup"'

	g=$(grep -w "GET" $request_log | wc -l)
	p=$(grep -w "PUT" $request_log | wc -l)
	h=$(grep -w "HEAD" $request_log | wc -l)
	d=$(grep -w "DELETE" $request_log | wc -l)
	total_request=$(($g + $p + $h + $d))

	printf "%-16s %-9s %-9s %-9s%-8s%-9s " $nodeIP $g $p $d $h $total_request

	test $total_request -eq 0 && continue

	for ErrorCode in $ERRORCODES; do

		g_error=$(awk "\$11==$ErrorCode" $get_log | wc -l)
		p_error=$(awk "\$11==$ErrorCode" $put_log | wc -l )
		d_error=$(awk "\$11==$ErrorCode" $delete_log | wc -l)
		h_error=$(awk "\$11==$ErrorCode" $head_log | wc -l )
		total_error=$(awk "\$11==$ErrorCode" $request_log | wc -l)

		printf "%-7s %-7s %-8s %-7s %-8s " $g_error $p_error $d_error $h_error $total_error

	done

	echo


	' | grep ^[0-9] | sort )"

	# Yes, could probably collapse a lot of these lines

	g_total=$(echo "$RequestData" | awk '{sum+=$2}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	p_total=$(echo "$RequestData" | awk '{sum+=$3}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	d_total=$(echo "$RequestData" | awk '{sum+=$4}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	h_total=$(echo "$RequestData" | awk '{sum+=$5}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	t_total=$(echo "$RequestData" | awk '{sum+=$6}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')

	TotalsLine1="$(printf "%-16s %-9s %-9s %-9s%-8s%-9s " "Req Totals:" $g_total $p_total $d_total $h_total $t_total)"
	TotalsLine2="$(printf "%-16s %-47s" "Req Error %:" " ")"

	RequestDataTrimmed="$(echo "$RequestData" | awk '{ sub(/([^ ]+ +){6}/,"") }1')" # Trim off the first fields in the RequestData Line, and trim each loop to count error totals for each error code type

	#echo "RequestData: $RequestData"
	#echo "RequestDataTrimmed: $RequestDataTrimmed"

	for ErrorCode in $ERRORCODES; do

		g_error_total=$(echo "$RequestDataTrimmed" | awk '{sum+=$1}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
		p_error_total=$(echo "$RequestDataTrimmed" | awk '{sum+=$2}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
		d_error_total=$(echo "$RequestDataTrimmed" | awk '{sum+=$3}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
		h_error_total=$(echo "$RequestDataTrimmed" | awk '{sum+=$4}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
		t_error_total=$(echo "$RequestDataTrimmed" | awk '{sum+=$5}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')

		TotalsLine1="${TotalsLine1}$(printf "%-7s %-7s %-8s %-7s %-8s " $g_error_total $p_error_total $d_error_total $h_error_total $t_error_total)"

		g_error_perc=$(if [[ $g_total -gt 0 ]]; then echo "scale=2; (${g_error_total}*100)/$g_total" | bc -l | awk '{printf "%.2f", $0}'; else echo 0.00; fi)
		p_error_perc=$(if [[ $p_total -gt 0 ]]; then echo "scale=2; (${p_error_total}*100)/$p_total" | bc -l | awk '{printf "%.2f", $0}'; else echo 0.00; fi)
		d_error_perc=$(if [[ $d_total -gt 0 ]]; then echo "scale=2; (${d_error_total}*100)/$d_total" | bc -l | awk '{printf "%.2f", $0}'; else echo 0.00; fi)
		h_error_perc=$(if [[ $h_total -gt 0 ]]; then echo "scale=2; (${h_error_total}*100)/$h_total" | bc -l | awk '{printf "%.2f", $0}'; else echo 0.00; fi)
		t_error_perc=$(if [[ $t_total -gt 0 ]]; then echo "scale=2; (${t_error_total}*100)/$t_total" | bc -l | awk '{printf "%.2f", $0}'; else echo 0.00; fi)

		TotalsLine2="${TotalsLine2}$(printf "%-7s %-7s %-8s %-7s %-8s " $g_error_perc $p_error_perc $d_error_perc $h_error_perc $t_error_perc)"

		RequestDataTrimmed="$(echo "$RequestDataTrimmed" | awk '{ sub(/([^ ]+ +){5}/,"") }1')"

	done

	echo -e "$RequestData"
	echo
	echo -e "$TotalsLine1"
	echo -e "$TotalsLine2"

	#printf "%-18s%-7s%-7s%-9s%-8s%-9s%-7s%-7s%-9s%-8s%-9s\n" "Req Totals:" $g_total $p_total $d_total $h_total $t_total $g_error_total $p_error_total $d_error_total $h_error_total $t_error_total
	#printf "%-18s%-40s%-7s%-7s%-9s%-8s%-9s\n" "Req Error %:" " " $g_error_perc $p_error_perc $d_error_perc $h_error_perc $t_error_perc
}


print_latency() {

	echo "                                                 Latency"
	echo "                            GET            |             PUT            |           DELETE"
	echo "Node             <1s       1-10s     >10s  |  <1s       1-10s     >10s  |  <1s       1-10s     >10s"


	LatencyData="$(${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "$RemoteCmdSetup"'

	get_lt1s=$(awk '\''$12<1000'\'' $get_log | wc -l)
	get_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $get_log | wc -l)
	get_gt10s=$(awk '\''$12>10000'\'' $get_log | wc -l)
	put_lt1s=$(awk '\''$12<1000'\'' $put_log | wc -l)
	put_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $put_log | wc -l)
	put_gt10s=$(awk '\''$12>10000'\'' $put_log | wc -l)
	del_lt1s=$(awk '\''$12<1000'\'' $delete_log | wc -l)
	del_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $delete_log | wc -l)
	del_gt10s=$(awk '\''$12>10000'\'' $delete_log | wc -l)

	printf "%-17s%-9s %-9s %-8s %-9s %-9s %-8s %-9s %-9s %-9s\n" $nodeIP $get_lt1s $get_gt1s $get_gt10s $put_lt1s $put_gt1s $put_gt10s $del_lt1s $del_gt1s $del_gt10s

	' | grep ^[0-9] | sort )"

	get_lt1s_total=$(echo "$LatencyData" | awk '{sum+=$2}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	get_gt1s_total=$(echo "$LatencyData" | awk '{sum+=$3}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	get_gt10s_total=$(echo "$LatencyData" | awk '{sum+=$4}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	put_lt1s_total=$(echo "$LatencyData" | awk '{sum+=$5}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	put_gt1s_total=$(echo "$LatencyData" | awk '{sum+=$6}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	put_gt10s_total=$(echo "$LatencyData" | awk '{sum+=$7}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	del_lt1s_total=$(echo "$LatencyData" | awk '{sum+=$8}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	del_gt1s_total=$(echo "$LatencyData" | awk '{sum+=$9}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')
	del_gt10s_total=$(echo "$LatencyData" | awk '{sum+=$10}END{if (NR > 0) {printf("%d", sum)}else{print "0"}}')


	echo -e "$LatencyData"

	echo
	printf "%-17s%-9s %-9s %-8s %-9s %-9s %-8s %-9s %-9s %-9s\n" "Latency Total:" $get_lt1s_total $get_gt1s_total $get_gt10s_total $put_lt1s_total $put_gt1s_total $put_gt10s_total $del_lt1s_total $del_gt1s_total $del_gt10s_total



}

print_sizes() {

	echo "                                      Request Sizes"
	echo "                              GET                             PUT"
	echo "Node             Avg (KB)  Max (KB)  Min (KB)    Avg (KB)  Max (KB)  Min (KB)"

	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "$RemoteCmdSetup"'

	get_size=$(awk '\''{sum+=$14}END{if (NR > 0) {printf("%.0f", sum/NR/1024)}else{print "-"}}'\'' $get_log)
	get_min=$(sort -k14 -n $get_log | awk '\''{print $14}'\'' | grep -v -- "-" | head -1 | awk '\''END{if (NR > 0) {printf("%.0f", $1/1024)}else{print "-"}}'\'')
	get_max=$(sort -k14 -nr $get_log | awk '\''{print $14}'\'' | grep -v -- "-" | head -1 | awk '\''END{if (NR > 0) {printf("%.0f", $1/1024)}else{print "-"}}'\'')

	put_size=$(awk '\''{sum+=$13}END{if (NR > 0) {printf("%.0f", sum/NR/1024)}else{print "-"}}'\'' $put_log)
	put_min=$(sort -k13 -n $put_log | awk '\''{print $13}'\'' | grep -v -- "-" | head -1 | awk '\''END{if (NR > 0) {printf("%.0f", $1/1024)}else{print "-"}}'\'')
	put_max=$(sort -k13 -nr $put_log | awk '\''{print $13}'\'' | grep -v -- "-" | head -1 | awk '\''END{if (NR > 0) {printf("%.0f", $1/1024)}else{print "-"}}'\'')

	printf "%-17s%-9s %-9s %-11s %-9s %-9s %-9s \n" $nodeIP $get_size $get_max $get_min $put_size $put_max $put_min
	' | grep ^[0-9] | sort

}

print_get_latency_per_size() {

	echo "                                GET Latency Per Request Size"
	echo "                           <10M                        10-100M                      >100M"
	echo "Node             <1s       1-10s     >10s  |  <1s       1-10s     >10s  |  <1s       1-10s     >10s"

	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "$RemoteCmdSetup"'

	get_lt10M_lt1s=$(awk '\''$12<1000'\'' $get_log | awk '\''$14<10000'\'' | wc -l)
	get_lt10M_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $get_log | awk '\''$14<10000'\'' | wc -l)
	get_lt10M_gt10s=$(awk '\''$12>10000'\'' $get_log | awk '\''$14<10000'\'' | wc -l)

	get_gt10M_lt1s=$(awk '\''$12<1000'\'' $get_log | awk '\''$14>=10000 && $14 <= 100000'\'' | wc -l)
	get_gt10M_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $get_log | awk '\''$14>=10000 && $14 <= 100000'\'' | wc -l)
	get_gt10M_gt10s=$(awk '\''$12>10000'\'' $get_log | awk '\''$14>=10000 && $14 <= 100000'\'' | wc -l)

	get_gt100M_lt1s=$(awk '\''$12<1000'\'' $get_log | awk '\''$14>100000'\'' | wc -l)
	get_gt100M_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $get_log | awk '\''$14>100000'\'' | wc -l)
	get_gt100M_gt10s=$(awk '\''$12>10000'\'' $get_log | awk '\''$14>100000'\'' | wc -l)

	printf "%-17s%-9s %-9s %-8s %-9s %-9s %-8s %-9s %-9s %-9s\n" $nodeIP $get_lt10M_lt1s $get_lt10M_gt1s $get_lt10M_gt10s $get_gt10M_lt1s $get_gt10M_gt1s $get_gt10M_gt10s $get_gt100M_lt1s $get_gt100M_gt1s $get_gt100M_gt10s

	' | grep ^[0-9] | sort

}

print_put_latency_per_size() {

	echo "                               PUT Latency Per Request Size"
	echo "                           <10M                        10-100M                      >100M"
	echo "Node             <1s       1-10s     >10s  |  <1s       1-10s     >10s  |  <1s       1-10s     >10s"

	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "$RemoteCmdSetup"'

	put_lt10M_lt1s=$(awk '\''$12<1000'\'' $put_log | awk '\''$13<10000'\'' | wc -l)
	put_lt10M_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $put_log | awk '\''$13<10000'\'' | wc -l)
	put_lt10M_gt10s=$(awk '\''$12>10000'\'' $put_log | awk '\''$13<10000'\'' | wc -l)

	put_gt10M_lt1s=$(awk '\''$12<1000'\'' $put_log | awk '\''$13>=10000 && $13 <= 100000'\'' | wc -l)
	put_gt10M_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $put_log | awk '\''$13>=10000 && $13 <= 100000'\'' | wc -l)
	put_gt10M_gt10s=$(awk '\''$12>10000'\'' $put_log | awk '\''$13>=10000 && $13 <= 100000'\'' | wc -l)

	put_gt100M_lt1s=$(awk '\''$12<1000'\'' $put_log | awk '\''$13>100000'\'' | wc -l)
	put_gt100M_gt1s=$(awk '\''$12>=1000 && $12<=10000'\'' $put_log | awk '\''$13>100000'\'' | wc -l)
	put_gt100M_gt10s=$(awk '\''$12>10000'\'' $put_log | awk '\''$13>100000'\'' | wc -l)

	printf "%-17s%-9s %-9s %-8s %-9s %-9s %-8s %-9s %-9s %-9s\n" $nodeIP $put_lt10M_lt1s $put_lt10M_gt1s $put_lt10M_gt10s $put_gt10M_lt1s $put_gt10M_gt1s $put_gt10M_gt10s $put_gt100M_lt1s $put_gt100M_gt1s $put_gt100M_gt10s

	' | grep ^[0-9] | sort

}

function print_top_gets() {
	echo
	echo "                                     Top GET request count by URL"
	echo "# GET Requests       URL"

	${SCRIPTDIR}/tools/eeviprexec -c "awk '{ print \$9 }' $get_log | awk -F/ '{ print \$4 }' | awk 'NF{ print \"/\"\$1 }' | sort | uniq -c " | grep -v -e '^[[:space:]]*$' | grep -v "Output from host" | awk '{sum[$2] += $1} END{for (i in sum) print sum[i],i}' | sort -rn | head -${NUMTOP} | awk '{ printf "%-20s %s\n",$1,$2 }'

}

function print_top_puts() {
	echo
	echo "                                     Top PUT request count by URL"
	echo "# PUT Requests       URL"

	${SCRIPTDIR}/tools/eeviprexec -c "awk '{ print \$9 }' $put_log | awk -F/ '{ print \$4 }' | awk 'NF{ print \"/\"\$1 }' | sort | uniq -c " | grep -v -e '^[[:space:]]*$' | grep -v "Output from host" | awk '{sum[$2] += $1} END{for (i in sum) print sum[i],i}' | sort -rn | head -${NUMTOP} | awk '{ printf "%-20s %s\n",$1,$2 }'

}

function print_top_talker_gets() {
	echo
	echo "                                     Top GET request count by client"
	echo "# GET Requests       Host"

	${SCRIPTDIR}/tools/eeviprexec -c "awk '{ print \$7 }' $get_log | sort | uniq -c" | grep -v -e '^[[:space:]]*$' | grep -v "Output from host" | awk '{sum[$2] += $1} END{for (i in sum) print sum[i],i}' | sort -rn | head -${NUMTOP} | awk '{ printf "%-20s %s\n",$1,$2 }'
}

function print_top_talker_puts() {
	echo
	echo "                                     Top PUT request count by client"
	echo "# PUT Requests       Host"

	${SCRIPTDIR}/tools/eeviprexec -c "awk '{ print \$7 }' $put_log | sort | uniq -c" | grep -v -e '^[[:space:]]*$' | grep -v "Output from host" | awk '{sum[$2] += $1} END{for (i in sum) print sum[i],i}' | sort -rn | head -${NUMTOP} | awk '{ printf "%-20s %s\n",$1,$2 }'
}



function report () {

	echo
	if [[ "$SUMMARY" == "true" || "$ALL" == "true" ]]; then
		print_requests
		echo
	fi
	if [[ "$LATENCY" == "true" || "$ALL" == "true" ]]; then
		print_latency
		echo
	fi
	if [[ "$SIZES" == "true" || "$ALL" == "true" ]]; then
		print_sizes
		echo
	fi
	if [[ "$LATENCY" == "true" || "$ALL" == "true" ]]; then
		print_get_latency_per_size
		echo
		print_put_latency_per_size
		echo
	fi
	if [[ "$TOP" == "true" || "$ALL" == "true" ]]; then
		print_top_gets
		print_top_puts
		print_top_talker_gets
		print_top_talker_puts
	fi

}


function clearfiles () {

	echo
	echo -n "Cleaning up temp files..."
	${SCRIPTDIR}/tools/eeviprexec -f "$MACHINES" -c "rm $request_log $get_log $put_log $delete_log $head_log 2> /dev/null" > /dev/null
	printDone
	exit
}



# -------------------- Main program logic begins here --------------------

echo "$SCRIPTNAME Version ${VERSION}"
echo

parse_args $*

trap clearfiles 1 2 3 13 15

collect_data
report
clearfiles
