#!/usr/bin/env bash
root=`dirname "$0"`
java -Xms64m -Xmx512m -jar $root/analysis-1.0.3.jar $@
