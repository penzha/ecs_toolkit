#!/usr/bin/python
import sys
import re
import datetime

class Display:

    def __init__(self):
        self.widthMax = 110
        self.firstdiv = 20

    def line(self):
        msg = '|'
        for i in range(1,self.widthMax):
            msg += '-'
        msg += "|\n"
        return(msg)

    def PrintFirstColumn(self, dat):
        datlength = len(dat) + 1
        msg = '|'
        if(dat != ""):
            msg += dat
        for i in range(datlength, self.firstdiv):
            msg += " "
        msg += '|'
        return(msg)

    def PrintSecondColumn(self,dat2):
        msg = ''
        if (dat2 != ""):
            datlength = len(dat2)
            datlength = self.firstdiv + datlength + 1
            msg += dat2
        else:
            datlength = self.firstdiv + 1
        for i in range(datlength, self.widthMax):
            msg += ' '
        msg += '|' + "\n"
        return(msg)

    def FormatToWrap(self, rawdata):
        eachset = rawdata.split(",")
        returnlist = list()
        for eachdata in eachset:
            eachdata = re.sub('\[','',eachdata)
            eachdata = re.sub('\]','',eachdata)
            returnlist.append(eachdata)
        return(returnlist)

    def ParseLineStat(self, lastMetrics, prevMetrics, currentTimestamp, prevTimestamp):
        TOTAL_SAMPLES_INDEX = 0
        TOTAL_SUCCESSFUL_REQUESTS_INDEX = 1
        TEST_DURATION = 2
        TRANSFERRED_BYTES_INDEX = 3
        TRANSFERRED_FAILED_BYTES_INDEX = 7
        TIME_FAILED_TOTAL = 8

        # (create,read,update,delete)*(small,med,large,xlarge)
        CATEGORIES_COUNT = 16

        SUCCESSFUL_REQUESTS_START_INDEX = 9
        SAMPLES_START_INDEX = SUCCESSFUL_REQUESTS_START_INDEX + CATEGORIES_COUNT
        ERRORS_START_INDEX = SAMPLES_START_INDEX + CATEGORIES_COUNT
        TOTAL_TIME_START_INDEX = ERRORS_START_INDEX + CATEGORIES_COUNT
        MIN_TIME_START_INDEX = TOTAL_TIME_START_INDEX + CATEGORIES_COUNT

        res_html = ''
        metrics = []

        has_prev_stat = (prevMetrics is not None) and (prevTimestamp is not None)
        if has_prev_stat:

            # Calculate stats for current time window:
            # (current_value - prev_value) for every metric except min/max response times
            metrics = [int(current) - int(prev) for (current, prev) in zip(lastMetrics[:MIN_TIME_START_INDEX],
                                                                                                                                       prevMetrics[:MIN_TIME_START_INDEX])]
            # Min and max response times are left as they are
            metrics += lastMetrics[MIN_TIME_START_INDEX:MIN_TIME_START_INDEX + CATEGORIES_COUNT * 2]

            time_window = datetime.timedelta(seconds=(currentTimestamp-prevTimestamp))
        else:
            # If previous stats are not available, duration is set to latest Wet test run duration
            metrics = [int(m) for m in lastMetrics]
            test_run_duration = lastMetrics[TEST_DURATION]
            time_window = datetime.timedelta(seconds=int(test_run_duration))

        res_html += "Duration (h:m:s): " + str(time_window)
        if not has_prev_stat:
            res_html += " (first time window)"
        res_html += "<br>"

        total_samples = metrics[TOTAL_SAMPLES_INDEX]
        total_successful_requests = metrics[TOTAL_SUCCESSFUL_REQUESTS_INDEX]
        res_html += "TPS: {0:.2f}".format(float(total_successful_requests) / time_window.seconds) + "<br>"

        transferred_bytes = metrics[TRANSFERRED_BYTES_INDEX]
        th_put_mbs = float(transferred_bytes) / 1024 / 1024 / time_window.seconds
        res_html += "Throughput: {0:.2f} MB/s".format(th_put_mbs) + "<br>"


        transferred_failed_bytes = metrics[TRANSFERRED_FAILED_BYTES_INDEX]
        time_failed_total = metrics[TIME_FAILED_TOTAL]

        local_finish = ERRORS_START_INDEX + CATEGORIES_COUNT
        total_error_request = 0
        for i in range(ERRORS_START_INDEX, local_finish):
            total_error_request += metrics[i]

        if total_error_request != 0:
            time_failed_average = int(round(time_failed_total / float(total_error_request)))
        else:
            time_failed_average = 0

        res_html += "Transferred failed bytes: {0}".format(transferred_failed_bytes)
        res_html += "; Error average requests latency: {0} ms".format(time_failed_average) + "<br>"

        # Use last metrics (not delta) for Verification coverage
        created_bytes = lastMetrics[TRANSFERRED_BYTES_INDEX+1]
        read_bytes    = lastMetrics[TRANSFERRED_BYTES_INDEX+2]
        updated_bytes = lastMetrics[TRANSFERRED_BYTES_INDEX+3]
        write_bytes   = created_bytes + updated_bytes
        # This is very draft verification coverage calculation
        # Based on accumptions that:
        # 1. All created/read/updated byte counters are for successful operations only
        # 2. Reads are evenly distributed across objects/ranges
        if write_bytes > 0:
            ver_cov_perc  = float(read_bytes) / ( write_bytes )
            if ver_cov_perc > 1:
                ver_cov_perc = 1  # make sure it can't go higher than 100%
            res_html += "Approx. verification coverage: {0:.2%}".format(ver_cov_perc) + "<br>"


        if total_samples > 0:
            passrate = float(total_successful_requests) / total_samples
        else:
            passrate = 0
        res_html += "Passrate: {0:.2%};".format(passrate)
        res_html += " samples: {0}; successful requests: {1}".format(total_samples, total_successful_requests)
        res_html += '<br><br>'

        samples_data = metrics[SAMPLES_START_INDEX:SAMPLES_START_INDEX + CATEGORIES_COUNT]
        successful_req_data = metrics[SUCCESSFUL_REQUESTS_START_INDEX:SUCCESSFUL_REQUESTS_START_INDEX + CATEGORIES_COUNT]
        error_data = metrics[ERRORS_START_INDEX:ERRORS_START_INDEX + CATEGORIES_COUNT]
        res_html += self.__FormatCategorizedTable(["Samples", "Successful Requests", "Errors"],
                                                                                          samples_data + successful_req_data + error_data, True)

        time_total = metrics[TOTAL_TIME_START_INDEX:TOTAL_TIME_START_INDEX + CATEGORIES_COUNT]
        time_average = [time / requests if requests > 0 else time
                                        for (time, requests)
                                        in zip(time_total, successful_req_data)]
        time_min_max = metrics[MIN_TIME_START_INDEX:MIN_TIME_START_INDEX + CATEGORIES_COUNT * 2]
        res_html += "<br>Successful requests latency(ms):<br>"
        res_html += self.__FormatCategorizedTable(["Average", "Min", "Max"], time_average + time_min_max, False)

        res_html += '<p style="font-size: 9pt; color: grey;">Small: < 128 KB; Medium: 128 KB .. 2 MB; Large: 2 MB .. 16 MB; Extra large: 16 MB .. 2 GB;</p>'

        # This html fragment also used by method WetStats in deployment.sh.
        # Please check output of deployment.sh WetStats if some modifications implemented in this output.
        return( res_html )

    def __FormatCategorizedTable(self, titles, data, print_total):
        operations = ["Create", "Read", "Update", "Delete"]
        sizes = ["Small", "Medium", "Large", "Extra Large"]
        op_count = len(operations)
        sz_count = len(sizes)
        titles_count = len(titles)

        def cell(value):
            return "<td>" + str(value) + "</td>"

        html = "<table border=\"1\" bordercolor=\"#EDEDED\" cellspacing=\"0\"><tr bgcolor=\"#EDEDED\"><td rowspan=\"2\">"
        for title in titles:
            html += "<td colspan=\"" + str(op_count) + "\">"  + title + "</td>"
        html += "</tr>\n<tr bgcolor=\"#EDEDED\">"
        for _ in range(titles_count):
            for operation in operations:
                html += cell(operation)
        html += "</tr>\n"

        for size_offset in range(sz_count):
            html += "<tr><td>" + sizes[size_offset] + "</td>"
            for i in range(titles_count):
                start_offset = i * op_count * sz_count + size_offset
                for op_offset in range(op_count):
                    html += cell(data[start_offset + op_offset * sz_count])
            html += "</tr>\n"

        if print_total:
            html += "<tr><td>Total</td>"
            for i in range(titles_count):
                for op_offset in range(op_count):
                    start = i * op_count * sz_count + op_offset * sz_count
                    html += cell(sum(data[start : start + sz_count]))
            html += "</tr>\n"

        html += "</table>"
        return html

    def DisplayHTMLFormat(self, time, prevTime, wetStat, prevWetStat, vsAlerts, sequentialSweepDic, vers, os_version, registry_version, fabric_version, wet_commit):
        htmlcont =''
        date = self.__FormatDate(datetime.datetime.now())
        htmlcont += '<tr><td>' + date + '</td>'
        htmlcont += '<td>Version & Last Install Time : ' + vers + '<br>'
        htmlcont += 'OS Version: ' + os_version + '<br>'
        htmlcont += 'Registry Version: ' + registry_version + '<br>'
        htmlcont += 'Fabric Version: ' + fabric_version + '<br>'
        htmlcont += 'WET commit: ' + wet_commit + '<br>'
        htmlcont += 'Last Updated Time: ' + self.__FormatDate(datetime.datetime.fromtimestamp(time)) + '<br>'
        listOfWarped = wetStat
        has_prev_stats = prevWetStat and prevTime
        prevListOfWarped = None
        prevUptime = None
        if (has_prev_stats):
            prevListOfWarped = prevWetStat
            prevUptime = prevTime
        res_html = ''
        if listOfWarped:
            res_html += self.ParseLineStat(listOfWarped, prevListOfWarped, time, prevUptime)
            htmlcont += 'WetStat:<br><br>' + res_html + '<br>'
        htmlcont += 'Sequential read verification was last executed at time ' + str(sequentialSweepDic) + '<br>'
        htmlcont += '</td>'
        htmlcont += '</tr>'
        return(htmlcont)

    def __FormatWSCriticalCount(self, ws_critical_dict):
        htmlcont = ''
        ws_critical_sum = sum(ws_critical_dict.values())
        htmlcont += 'WS Critical count: ' + str( ws_critical_sum )
        if ws_critical_sum > 0:
            htmlcont += ' (datanodes: ' + '; '.join(
                    [ip + " - " + str(count) for (ip, count) in ws_critical_dict.items()]) + ')'
        return(htmlcont)

    def DisplayFormat(self,tb,time,vers,Dic,cm_start_cnt,geo_rec_cnt,rm_strt_cnt):
        htmlcont = ''

        listOfWarped = Dic
        htmlcont += tb + "\t"
        htmlcont += time + "\t"
        htmlcont += vers + "\t"
        for res in listOfWarped:
            htmlcont +=   str(res) + "\,"
        htmlcont += "\t"
        htmlcont += 'CM service Restart count: ' + str(cm_start_cnt) + ','
        htmlcont += 'RM service Restart count: ' +  str(geo_rec_cnt) + ','
        htmlcont += 'Georeceiver Restart start count: ' + str(rm_strt_cnt)

        htmlcont += "\n"
        return(htmlcont)

    def DisplayHTMLFormatForVSAlert(self, time, prev_time, vsAlerts, datanode_errors_present, error_table, datanodes, restarts, vers, os_version, registry_version, fabric_version, wet_commit):
        htmlcont =''
        date = self.__FormatDate(datetime.datetime.now())
        htmlcont += '<tr><td>' + date + '</td>'
        htmlcont += '<td>Version & Last Install Time : ' + vers + '<br>'
        htmlcont += 'OS Version: ' + os_version + '<br>'
        htmlcont += 'Registry Version: ' + registry_version + '<br>'
        htmlcont += 'Fabric Version: ' + fabric_version + '<br>'
        htmlcont += 'WET commit: ' + wet_commit + '<br>'
        htmlcont += 'Last Updated Time: ' + self.__FormatDate(datetime.datetime.fromtimestamp(time)) + '<br>'
        htmlcont += 'Client/Server Critical errors: ' + str(vsAlerts) + '<br>'
        htmlcont += '<h3>Errors in services on datanodes ('
        if (time and prev_time):
            htmlcont += 'From: ' + \
               self.__FormatDate(datetime.datetime.fromtimestamp(prev_time)) + \
               '; To: ' + \
               self.__FormatDate(datetime.datetime.fromtimestamp(time))
        else:
            htmlcont += 'From start'
        htmlcont += '):</h3><br>'

        if not error_table:
            htmlcont += 'Errors were not found.'
            if datanode_errors_present:
                htmlcont += ' Please check datanode errors below.'
            htmlcont += '</br>'
        else:
            htmlcont += '<table border=\"1\" bordercolor=\"#EDEDED\" cellspacing=\"0\">'
            num_of_columns = len(datanodes)

            for service in error_table:
                criticals = 0
                htmlcont += '<tr  bgcolor=\"#EDEDED\"><td colspan="%d"><h3>Service: %s' % (num_of_columns + 2, service)
                html_down = '</h3></td></tr><tr bgcolor=\"#EDEDED\"><td rowspan="2"><h4>Error Location</h4></td><td rowspan="2"><h4>Message (first found)</h4></td>'
                html_down += '<td colspan=%s><h4>Datanodes (number of restarts in parentheses)</h4></td></tr>' % num_of_columns
                html_down += '<tr bgcolor=\"#EDEDED\">'
                for dn in datanodes:
                    if service not in restarts:
                        restarts[service] = dict()
                    if dn not in restarts[service]:
                        restarts[service][dn] = 0
                    html_down += '<td><h4>%s<br>(%d)</h4></td>' % (dn, restarts[service][dn])

                for pattern in error_table[service]:
                    rr = re.search(r'(\S+)\s+(\d+)', pattern)
                    if rr:
                        location = rr.group(1) + ' (line ' + rr.group(2) + ')'
                    else:
                        print "Strange line: " + pattern
                    html_temp = '\n<tr><td>%s</td>' % location

                    content = ''
                    dns = []
                    for d in range(len(datanodes)):
                        if datanodes[d] not in error_table[service][pattern]:
                            dns.append(0)
                        else:
                            content = error_table[service][pattern][datanodes[d]]['content']
                            dns.append(error_table[service][pattern][datanodes[d]]['value'])
                            if 'WSCritical' in content:
                                criticals += error_table[service][pattern][datanodes[d]]['value']

                    if content and 'NoError' not in content:
                        html_temp += '<td>%s</td>' % content
                        for d in range(len(datanodes)):
                            html_temp += '<td>%s</td>' % dns[d]

                    if content:
                        html_down += html_temp + '</tr>\n'
                htmlcont += '&nbsp;&nbsp;|&nbsp;&nbsp;Critical errors: ' + str(criticals) + html_down
            htmlcont += '</table>'

        htmlcont += '</td>'
        htmlcont += '</tr>'
        return(htmlcont)

    def __FormatDate(self,date):
        return date.strftime("%d/%m/%Y %H:%M")

if __name__ == "__main__":
    pp = Display()
    aa = ('testbed1','testbed2')
    ddic = {'testbed1':'[WET:2000;max:50000;totalrequest:120000;kjasjdh:121212;asdasdsak:123123],[StorageInfo-askdjfhkjasdalfhkasjdlflkasjdfhlaksjdf],[ControlNode-alskdjflasdflkiwerl]' ,
       'testbed2':'[WET:2000;max:50000;totalrequest:120000;kjasjdh:121212;asdasdsak:123123;otherval:9999],[StorageInfo-askdjfhkjasdalfhkasjdlflkasjdfhlaksjdf][ControlNode-alskdjflasdflkiwerl]'};
    logms = pp.DisplayFormat(aa,ddic)
#       main(self)
