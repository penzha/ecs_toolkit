#!/usr/bin/env python

import subprocess, re, os, logging 
import json

logger = logging.getLogger('logs_collector')

class Container:
    def __init__(self, **kwards):
        default = dict(
                ip       = 'localhost',
                images   = ['emcvipr/object:latest', 'emcvipr/object:'], 
                cmd_opts = '-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no', 
                cid      = None,
                skip_sshpass = False
        )
        for key, value in default.iteritems():
            if kwards is not None and key in kwards:
                value = kwards[key] 
            self.__dict__[key] = value            

        ps = self.do_ssh('docker ps --no-trunc')

        if len(ps) <= 1:
            logger.debug('No docker containers found')
        else:
            regexp = '(?:%s)' % '|'.join(self.images)
            c_line = (filter(lambda l: re.search(regexp, l) , ps) or [None])[0]
    
            if c_line is None:
                logger.debug('Docker container not found for image(s): ' + str(self.images))
            else:
                cid = re.split(r'\s{2,}', c_line)
                if len(cid) == 0:
                    logger.debug('Can\'t get object docker container ID')
                else:
                    self.cid = cid[0]

        if self.cid is not None:
            info           = self.do_ssh('docker info')
            storage_driver = filter(lambda l: re.search('Storage Driver', l), info)[0]
            storage_driver = re.findall('(\w+)$', storage_driver)[0]
            get_root       = getattr(self, storage_driver)
            if get_root is None:
                logger.debug('Unsupported storage driver \'' + storage_driver + '\'')
            else:
                self.root  = get_root()
                logger.debug('Docker root: %s' % self.root)

    def devicemapper(self):
        return os.path.join('/var/lib/docker/devicemapper/mnt', self.cid, 'rootfs') 

    def btrfs(self):
        return os.path.join('/var/lib/docker/btrfs/subvolumes/', self.cid)

    def get_abs_path(self, dir):
        dir = re.sub(r'^/', '', dir)
        abs_dir = os.path.join(self.root, dir)
        readlink = map(str.strip, self.do_ssh("readlink %s" % abs_dir))
        bind = ''
        if len(readlink) > 0:
            link = readlink[0]
            inspect = ''.join(map(str.strip, self.do_ssh('docker inspect %s' % self.cid)))
            inspect = json.loads(inspect)
            binds   = inspect[0]['HostConfig']['Binds']
            #logger.debug(json.dumps(binds, sort_keys=True, indent=4, separators=(',', ':')))
            binds   = filter(lambda l: re.search(':%s(:\w+)?$' % link, l), binds) 
            if len(binds) > 0:
                bind = binds[0].split(':')[0]
                
        if bind:
            abs_path = bind
        else:
            abs_path = os.path.join(self.root, dir)

        return abs_path

    def get_files_list(self, dir, mmin=None):
        find = 'find %s -type f' % self.get_abs_path(dir)
        if mmin is not None:
            find = '%s -mmin -%s' % (find, mmin)
        find = '%s -printf %s' % (find, repr('%f\\n')) 

        return map(str.strip, self.do_ssh(find))

    def copy_file(self, remoteFile, localDir):
        return self.do_scp(remoteFile, localDir)

    def do_scp(self, src, tgt):
        return self.sshpass('scp -Cp %s root@%s:%s %s' % (self.cmd_opts, self.ip, src, tgt))

    def do_ssh(self, cmd):
        return self.sshpass('ssh -q %s root@%s %s' % (self.cmd_opts, self.ip, cmd))
        
    def sshpass(self, cmd):
        logger.debug('Exec cmd: %s' % cmd)
        if self.skip_sshpass:
            full_cmd = cmd
        else:
            full_cmd = 'sudo /usr/local/bin/sshpass -p ChangeMe %s' % cmd,
        sshpass = subprocess.Popen(full_cmd,
                                   shell  = True,
                                   stdout = subprocess.PIPE,
                                   stderr = subprocess.PIPE,
        )
        if sshpass.returncode is not None:
            logger.debug('ERROR %s\n%s' % (cmd, sshpass.stderr.readlines()))
            
        return sshpass.stdout.readlines()
