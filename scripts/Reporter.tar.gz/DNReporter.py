#!/usr/bin/python

import pickle
import os
import Reporter as r
import sys
import re
import logging
import datetime

class DNReporter(r.Reporter):

    def __init__(self, log_type, timestamp):
        logging_name = datetime.datetime.now().strftime("dnreporter_%Y_%m_%d_%H_%M.log")
        logging_path = "/opt/wet/reporting/logs"
        if not os.path.isdir(logging_path):
            os.makedirs(logging_path)
        # All logs will be generated with level CRITICAL. This is the production mode. If check behavior
        # of reporter is needed then change log level to DEBUG there.
        logging.basicConfig(filename=os.path.join(logging_path, logging_name),level=logging.CRITICAL, \
                            format='%(asctime)s %(levelname)s:%(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
        self.version = '2.0'
        self.LogType = log_type
        self.Group = 'ECSGroup'
        self.Dir = '/opt/storageos'
        self.LogDir = self.get_log_dir()
        self.Conf = '/root'
        self.ReportConf = '/root/Reporter_%s.state' % log_type
        self.LogPattern = '%s-error.log\.*' % log_type
        self.error = ''
        self.metadata = dict()
        self.store_opts = dict()
        self.store_opts['stat'] = dict()
        self.stat = dict()
        self.config = self.Conf + '/dnreporter_config.xml'
        self.log_file_name = '%s-error.log' % log_type
        self.get_host_metadata()
        self.get_object_state()
        self.stat_file = '/root/service_%s_stat.reporter' % log_type
        self.log_stat = dict()
        self.wet_start_timestamp = timestamp

    def get_log_dir(self):
        import subprocess
        import json

        def execute(cmd):
            res = subprocess.Popen(cmd, shell  = True, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
            if res.returncode is not None:
                print 'ERROR %s\n%s' % (cmd, res.stderr.readlines())
            return res.stdout.readlines()

        images = ['emcvipr/object:latest', 'emcvipr/object:']
        ps = execute('docker ps --no-trunc')
        if len(ps) <= 1:
            print "No docker containers found"
        else:
            regexp = '(?:%s)' % '|'.join(images)
            c_line = (filter(lambda l: re.search(regexp, l) , ps) or [None])[0]
            
            if c_line is None:
                print "Docker container not found for image(s): " + str(images)
            else:
                id = re.split(r'\s{2,}', c_line)[0]
                if not id: 
                    print "Can't get object docker container ID"

        if id is not None:
            info = execute('docker info')
            storage_driver = filter(lambda l: re.search('Storage Driver', l), info)[0]
            storage_driver = re.findall('(\w+)$', storage_driver)[0]
            if storage_driver == 'devicemapper':
                get_root = os.path.join('/var/lib/docker/devicemapper/mnt', id, 'rootfs', 'opt/storageos/logs')
            elif storage_driver == 'btrfs':
                get_root = os.path.join('/var/lib/docker/btrfs/subvolumes/', id, 'opt/storageos/logs')
            if get_root is None:
                print "Unsupported storage driver '" + storage_driver + "'" 
        readlink = map(str.strip, execute("readlink %s" % get_root))
        bind = ''
        if len(readlink) > 0:
            link = readlink[0]
            inspect = ''.join(map(str.strip, execute('docker inspect %s' % id)))
            inspect = json.loads(inspect)
            binds   = inspect[0]['HostConfig']['Binds']
            #print json.dumps(binds, sort_keys=True, indent=4, separators=(',', ':'))
            #bind    = filter(lambda l: re.search('%s$' % link, l), binds)[0] 
            #bind    = re.sub(r'^%s/?(.*?):.*' % link, r'\1', bind)
            binds   = filter(lambda l: re.search(':%s(:\w+)?$' % link, l), binds) 
            if len(binds) > 0:
                bind = binds[0].split(':')[0]
        if bind:
            abs_path = bind
        else:
            abs_path = get_root

        return abs_path


    def save_stat(self):
        self.error = ''
        if self.log_stat:
            try:
                stat_dump = open(self.stat_file, 'w')
            except:
                self.error = 'Failed to open file ' + self.stat_file + ' for write.'
                logging.error(self.error)
                return 0
            pickle.dump(self.log_stat, stat_dump, pickle.HIGHEST_PROTOCOL)
            stat_dump.close()
        return 1

    def load_stored_stat(self):
        self.error = ''
        if os.path.isfile(self.stat_file):
            try:
                stat_dump = open(self.stat_file, 'r')
            except:
                self.error = 'Failed to open file ' + self.stat_file
                logging.error(self.error)
                return 0
            try:
                self.log_stat = pickle.load(stat_dump)
            except:
                self.error = 'Failed to read from file ' + self.stat_file
                logging.error(self.error)
                os.unlink(self.stat_file)
                return 0
            stat_dump.close()
        else:
            logging.debug('File ' + self.stat_file + ' does not exist')
        return 1

    def update_stat(self, struct):
        id = struct['metadata']['name'] + ' ' + struct['metadata']['line']
        if id in self.log_stat:
            self.log_stat[id]['value'] += int(struct['value'])
        else:
            self.log_stat[id] = {
                'content': self.fix_length(struct['metadata']['text']),
                'name': struct['metadata']['name'],
                'line': struct['metadata']['line'],
                'errortype': struct['name'],
                'value': int(struct['value'])
            }
        return

    def fix_length(self, content):
        result = content
        if len(content) > 500:
            result = content[:250] + ' ... ' + content[-250:]
        return result

if __name__ == "__main__":
    ts = None
    if len(sys.argv) > 1:
        try:
            ts = int(sys.argv[1])
        except:
            print "Cannot convert parameter %s to integer." % sys.argv[1]
    os.nice(5)
    lock_file = '/tmp/dnreporter.lock'
    # We have to check if DNReporter is already running in the system and if it is true we do not have to do anything
    if (os.path.isfile(lock_file)):
        l_file = open(lock_file, 'r')
        ext_pid = l_file.readline()
        l_file.close()
        if ext_pid in os.listdir('/proc'):
            print "Another DNReporter process is already running."
            print "Exiting..."
            sys.exit(0)
    l_file = open(lock_file, 'w')
    my_pid = os.getpid()
    l_file.write(str(my_pid))
    l_file.close()

    reporter = ''
    for service in ('objheadsvc', 'rm', 'georeceiver', 'georeplayer', 'ssm', 'cassvc', 'dtquery', \
                    'eventsvc', 'metering', 'provisionsvc', 'resourcesvc', 'stat', 'vnest', 'cm', 'blobsvc'):
        reporter = DNReporter(service, ts)
        reporter.parse_error_log()
        reporter.load_stored_stat()
        reporter.flush(None)
        reporter.save_stat()
        reporter.save_object_state()
    os.unlink(lock_file)
