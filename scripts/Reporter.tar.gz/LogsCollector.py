import os, re, time, sys, math, logging
import Container as c

if 'DEBUG_LC' in os.environ:
    lvl = logging.DEBUG
else:
    lvl = logging.INFO

logger = logging.getLogger('logs_collector')
logger.handlers = []
logger.setLevel(lvl)
formatter = logging.Formatter('[%(asctime)s : %(levelname)+5s] %(message)s')
ch = logging.StreamHandler()
ch.setFormatter(formatter)
ch.setLevel(lvl)
logger.addHandler(ch)

class LogsCollector:

    def __init__(self, **kwards):
        init = dict(
            fsType       = 'local',
            logDir       = '/opt/wet/logs',
            logPattern   = 'wet-error\.log.*',
            sortBy       = 'mtime',
            ip           = 'localhost',
            remoteLogDir = '/opt/wet/logs',
            container    = None,
            recent_ts    = None,
        )

        for key, value in init.iteritems():
            if kwards is not None and key in kwards:
                value = kwards[key]
            self.__dict__[key] = value

        # set/replace attribute by method with name of value
        self.sortBy   = getattr(self, self.sortBy)
        self.get_logs = getattr(self, 'get_sorted_logs_' + self.fsType)

    def mtime(self, file):
        # (mode, ino, dev, nlink, uid, gid, size, atime, MTIME, ctime)
        return os.stat(file)[8]

    def recent(self):
        mmin = None
        if self.recent_ts is not None and self.recent_ts > 0:
            mmin = int(math.ceil((int(time.time()) - int(self.recent_ts)) / 60))
        return mmin    


    def get_logs_local(self):
        logs = filter(lambda f: re.match(self.logPattern, f), os.listdir(self.logDir))
        logs = map   (lambda f: '/'.join((self.logDir, f)), logs)

        if self.recent() is not None:
            logs = filter(lambda f: int(self.mtime(f)) > int(self.recent_ts), logs) 

        return logs

    def get_sorted_logs_local(self):
        logs = self.get_wo_collisions(getattr(self, 'get_logs_local'))
        # key is callable
        return sorted(logs, key=self.sortBy, reverse=True)


    def get_logs_container(self):
        remote = self.container.get_files_list(self.remoteLogDir, self.recent())
        remote = filter(lambda f: re.match(self.logPattern, f), remote)
        local  = filter(lambda f: re.match(self.logPattern, f), os.listdir(self.logDir))
        newest = set(remote) - set(local)
        return newest

    def get_sorted_logs_container(self):

        if not self.container:
            self.container = c.Container(ip=self.ip)

        logs = self.get_wo_collisions(getattr(self, 'get_logs_container'))

        if logs.count > 0:
            top_log = filter(lambda f: re.match(self.logPattern, f) \
                                         and re.search('\.log$', f), os.listdir(self.logDir))
            if len(top_log) > 0 and top_log[0] not in logs:
                logs.append(top_log[0])

            remoteDir = self.container.get_abs_path(self.remoteLogDir)
            for file in logs:
                self.container.copy_file(os.path.join(remoteDir, file), self.logDir)
            logs = self.get_sorted_logs_local()

        return logs

    def get_wo_collisions(self, get_logs_attr):
        for i in range(10):
            logs = get_logs_attr()
            if len(logs) == 0: break
            if self.collision(logs):
                logs = []
                logger.debug('Collision found')
            else:
                break
            logger.debug('Sleeping ...')
            time.sleep(1)
        return list(logs)

    def collision(self, logs):
        tmp = filter(lambda f: re.search('\.gz$', f), logs)
        tmp = set(map(lambda f: re.sub(r'(.*?)\.gz$', r'\1', f), tmp))
        return len(tmp.intersection(set(logs))) > 0
