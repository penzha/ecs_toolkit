#!/usr/bin/python
import re
import sys
import os
import time
import datetime
import socket
import subprocess
import Display as d
import pickle
import xml.etree.ElementTree as ET
import gzip
import LogsCollector as lc 
import logging
import copy

class Reporter(object):

    def __init__(self, timestamp):
        logging_name = datetime.datetime.now().strftime("dnreporter_%Y_%m_%d_%H_%M.log")
        logging_path = "/opt/wet/reporter_logs"
        if not os.path.isdir(logging_path):
            os.mkdir(logging_path)
        # All logs will be generated with level CRITICAL. This is the production mode. If check behavior
        # of reporter is needed then change log level to DEBUG there.
        logging.basicConfig(filename=os.path.join(logging_path, logging_name),level=logging.CRITICAL, \
                            format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
        self.version = '1.03'
        self.Group = 'WetGroup'
        self.LogType = 'WetLogs'
        self.Dir = '/opt/wet'
        self.LogDir = self.Dir + '/logs'
        self.Conf = self.Dir + '/conf'
        self.ReportConf = '/tmp/Reporter.state'
        self.ConfFile = self.Conf + '/testbed.conf'
        self.LogPattern = 'wet-error\.log.*'
        self.error = ''
        self.datanodes = dict()
        self.grindernodes = dict()
        self.controlnodes = dict()
        self.me = dict()
        self.you = dict()
        self.Password = 'ChangeMe'
        self.metadata = dict()
        self.store_opts = dict()
        self.store_opts['stat'] = dict()
        self.stat = dict()
        self.config = self.Conf + '/reporter_config.xml'
        self.wet_start_timestamp = timestamp

        self.get_object_state()
        self.error = ''

        if os.path.isfile(self.ConfFile):
            try:
                content_file = open(self.ConfFile, 'r')
            except:
                self.error = 'Failed to open file: ' + self.ConfFile
                return
            for line in content_file:
                if re.match(r'^#', line):
                    continue
                m = re.match(r'.*?\:\[(.*?)\]\[(.*?)\]\[(.*?)\]\[(.*?)\]\[(.*?)\]', line)
                if m:
                    grindernode = m.group(1)
                    datanode = m.group(2)
                    controlnode = m.group(3)
                    me = m.group(4)
                    you = m.group(5)
                    grindernode = re.sub(r'grinder\:', '', grindernode)
                    grindernode = re.sub(r'\s+', ' ', grindernode)
                    datanode = re.sub(r'datanode\:', '', datanode)
                    datanode = re.sub(r'\s+', ' ', datanode)
                    controlnode = re.sub(r'controlnode\:', '', controlnode)
                    controlnode = re.sub(r'\s+', ' ', controlnode)
                    me = re.sub(r'me\:', '', me)
                    you = re.sub(r'you\:', '', you)

                    self.datanodes = datanode.split(" ")
                    self.grindernodes = grindernode.split(" ")
                    self.controlnodes = controlnode.split(" ")
                    self.me = me
                    self.you = you
                    
                else:
                    logging.error('Failed to parse file: ' + self.ConfFile)
                    return
        self.get_host_metadata()
        return

    def get_timestamp(self, string):
        self.error = ''

        for ts in self.timestamps:
            res = ts.search(string)
            if res:
                timestamp_key = ts
                break
        else:
            self.debug = 'Cannot get date from string:' + string
            logging.error(self.error)
            return None
        date = res.group()
        timestamp = int(time.mktime(datetime.datetime.strptime(date, self.timestamps[timestamp_key]).timetuple()))
        return timestamp

    def keydate_value(self, keydate):
        return 'KeyDate' in self.store_opts and keydate == self.store_opts['KeyDate']

    def logs_collector_params(self):
        return dict(logDir=self.LogDir, logPattern=self.LogPattern)

    def parse_error_log(self):
        self.error = ''
        self.Log = dict()
        self.parse_config()
        if self.error:
            print self.error
            sys.exit(1)

        fst_processed_timestamp = ''
        lst_processed_line_num  = 0
        line_number             = 0 
        date_first_line         = ''
        last_timestamp          = ''
        logging.info("Creating object LogCollector...")
        logs_collector          = lc.LogsCollector(**self.logs_collector_params())
        logging.info("Done.")

        self.timestamps = dict()
        for fm in self.conf_tree.findall('timeformats'):
            for timestamp in fm.findall('timestamp'):
                if 'value' in timestamp.attrib and 'mask' in timestamp.attrib:
                    self.timestamps[re.compile(timestamp.attrib['value'])] = timestamp.attrib['mask']
                else:
                    logging.error("Tag <timestamp> has no attribute 'value' or 'mask'")

        for lfile in logs_collector.get_logs():
            logging.info("Parsing file: %s" % lfile)
            print "Parsing file: %s" % lfile
            stop_processing = False
            if not os.path.isfile(lfile):
                self.error = 'Log file ' + lfile + ' does not exist'
                logging.error(self.error)
                return
            try:
                log = self.openfile(lfile)
            except:
                self.error = 'Could not open Log file ' + lfile
                logging.error(self.error)
                continue
            try:
                log_lines = log.readlines()
            except:
                self.error = 'Could not read from Lof file ' + lfile
                logging.error(self.error)
                continue
            log.close()
            if len(log_lines) == 0:
                continue

            log_length = len(log_lines)

            # Get date from first line to found log with stored KeyDate
            first_line = log_lines[0]
            for ts in self.timestamps:
                res = ts.search(first_line)
                if res:
                    date_first_line = res.group(1)
                    # fist processed file
                    if fst_processed_timestamp == '':
                        fst_processed_timestamp = date_first_line
                        lst_processed_line_num = log_length
                    break
            else:
                logging.error("Cannot get date")

            line_number = 0
            # Put marker of lines to stored position if previous processing stopped somewhere in it
            if self.keydate_value(date_first_line):
                line_number = self.store_opts['line_number']

            while 1:
                # Get log line or going out from loop
                if log_length > line_number:
                    line = log_lines[line_number]
                    line_number += 1

                else:
                    # If we've found stored timestamp in log file we have to end process it and stop all processing.
                    if self.keydate_value(date_first_line):
                        stop_processing = True
                    break

                # Processing line with expressions from config
                for c_line in self.config_structure:
                    # Checking conditions
                    cpass = True
                    for cond in c_line['conditions']:
                        if not cond.search(line):
                                cpass = False
                                break
                    if cpass:
                        timestamp = self.get_timestamp(line)
                        # Check timestamp. If timestamp is None we have to stop processing current line.
                        # If timestamp is not None but it older than WET start time we have to stop all processing.
                        if timestamp and self.wet_start_timestamp > timestamp:
                            stop_processing = True
                            continue
                        self.appendLog(line, c_line['items'], timestamp)
                        last_timestamp = timestamp
            # Generate a portion of output from current log.
            self.flush(last_timestamp)

            if stop_processing is True: break

        # Update actual position in Logs
        self.store_opts['KeyDate']     = fst_processed_timestamp
        self.store_opts['line_number'] = lst_processed_line_num
        return 1

    def appendLog(self, line, items, timestamp):
        # Return None if timestamp could not be found.
        if self.error:
            return None
        if timestamp not in self.Log:
            self.Log[timestamp] = []
        # Extract metrics names, values and metadata from line
        for regexps in items:
            for regexp in regexps:
                m = regexp.search(line)
                if m:
                    for mc in regexps[regexp]:
                        metric = copy.deepcopy(mc)
                        for meta in metric['metadata']:
                            metric['metadata'][meta] = m.group(metric['metadata'][meta])
                        if metric['value'] == 'event':
                            for i in range(len(self.Log[timestamp])):
                                if self.Log[timestamp][i]['name'] == metric['name'] and \
                                        self.Log[timestamp][i]['metadata'] == metric['metadata']:
                                    self.Log[timestamp][i]['value'] += 1
                                    break
                            else:
                                metric['value'] = 1
                                self.Log[timestamp].append(metric)
                        else:
                            metric['value'] = m.group(metric['value'])
                            self.Log[timestamp].append(metric)
        return timestamp

    # In this method each metric metadata dictionary may be filled with additional items.
    def fill_metric_metadata(self, metric_metadata):
        pass

    # this openfile method can open files and archives and make handler with unified interface
    def openfile(self, filename):
        if os.path.isfile(filename):
            if re.search('\.gz$', filename):
                filehandler = gzip.open(filename, 'r')
            else:
                filehandler = open(filename, 'r')
            return filehandler
        else:
            return None

    def parse_config(self):
        self.error = ''
        # Get XML configuration from file
        try:
            tree = ET.parse(self.config)
        except Exception as e:
            self.error = "Can't parse config XML file " + self.config + " -- " + str(e)
            logging.error(self.error)
            return 0
        # Store original tree in object
        self.conf_tree = tree.getroot()
        # Parcing config with compilation of all regular expressions and making easy structure.
        lines = []
        line_dict = dict()
        # 'line' is the root element in structure
        for c_line in self.conf_tree.findall('line'):
            conditions = []
            # Finding conditions and put them into array
            for cond in c_line.findall('conditions'):
                for tif in cond.findall('if'):
                    try:
                        comp_regexp = re.compile(tif.attrib['value'])
                    except:
                        logging.error('Could not compile regular expression /%s/' % tif.attrib['value'])
                        continue
                    conditions.append(comp_regexp)
            line_dict['conditions'] = conditions
            items = []
            # Parsing items and metrics
            for item in c_line.findall('items'):
                regexps = dict()
                for regexp in item.findall('regexp'):
                    control_regexp = re.compile(regexp.attrib['re'])
                    mxs = []
                    # Generating metric dictionary
                    for mx in regexp.findall('metric'):
                        metric = dict()
                        metric['name'] = mx.attrib['name']
                        if 'value' in mx.attrib:
                            metric['value'] = int(mx.attrib['match'])
                        else:
                            metric['value'] = 'event'

                        kw = mx.find('keywords')
                        if kw is not None:
                            kws = kw.attrib['list'].split(',')
                            metric['keywords'] = kws

                        metas = dict()
                        for meta in mx.findall('metadata'):
                            metas[meta.attrib['name']] = int(meta.attrib['match'])
                        metric['metadata'] = metas
                        mxs.append(metric)
                    regexps[control_regexp] = mxs
                items.append(regexps)
            line_dict['items'] = items
        lines.append(line_dict)
        self.config_structure = lines

        return 1

    def save_object_state(self):
        self.error = ''
        try:
            report = open(self.ReportConf, 'w')
        except:
            self.error = 'Failed to open file ' + self.ReportConf + ' for write.'
            logging.error(self.error)
            return 0
        pickle.dump(self.store_opts, report, 0)
        logging.info('Object state saved:')
        logging.info(str(self.store_opts))
        report.close()
        return 1

    def get_object_state(self):
        self.error = ''
        
        if os.path.isfile(self.ReportConf):
            try:
                report = open(self.ReportConf, 'r')
            except:
                self.error = 'Failed to open file ' + self.ReportConf
                logging.error(self.error)
                return 0
            try:
                self.store_opts = pickle.load(report)
                report.close()
            except:
                report.close()
                os.remove(self.ReportConf)
                self.error = 'File corrupted ' + self.ReportConf + '. Removing...'
                logging.error(self.error)
                return 0
            logging.info('Object state loaded:')
            logging.info(str(self.store_opts))
        else:
            self.error = 'File does not exist ' + self.ReportConf
            logging.error(self.error)
            return 0
        return 1

    def get_host_metadata(self):
        self.error = ''
        if self.metadata:
            return 1
        self.metadata['hostname'] = socket.gethostname()
        return

    # Variable last_timestamp set to number of last timestamp or None and if it
    # contains a timestamp then only lines before this timestamp in 20 sec will be printed
    def flush(self, last_timestamp):
        logging.info("Flushing from %s" % last_timestamp)
        ts2del = []
        for ts in self.Log:
            if type(last_timestamp) is int:
                if int(ts) > int(last_timestamp) - 20:
                    continue
            for metric in self.Log[ts]:
                self.update_stat(metric)
            ts2del.append(ts)
        for td in ts2del:
            del self.Log[td]
        return

    # Value for 'source' field in w4n raw format line
    def get_apg_source(self):
        return "WetLogs"

    def update_stat(self, struct):
        return

