#!/usr/bin/env python

import pickle
import os
import subprocess
import re

def execute(cmd):
    res = subprocess.Popen(cmd, shell  = True, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
    if res.returncode is not None:
        print 'ERROR %s\n%s' % (cmd, res.stderr.readlines())
    return res.stdout.readlines()

error_table = dict()
service_files = execute('ls /root | grep service_')
for service_file in service_files:
    service_check = re.search('service_([^_\n]+)', service_file)
    if not service_check:
        print "Troubles with extract service name from filename: " + service_file
        continue
    service = service_check.group(1)
    file = os.path.join('/root', service_file.rstrip())
    stat_dump = open(file, 'r')
    stat = pickle.load(stat_dump)
    for id in stat:
        if service not in error_table:
            error_table[service] = dict()
        if id not in error_table[service]:
            error_table[service][id]=stat[id]
    os.unlink(file)
    for service in error_table:
        print 
        print '*********************************************************************'
        print "SERVICE: %s" % service
        print '*********************************************************************'
        for id in error_table[service]:
            rr = re.search(r'(\S+)\s+(\d+)', id)
            if rr:
                location = rr.group(1) + ' (line ' + rr.group(2) + ')'
            else:
                continue
            print "FOUND: %s" % location
            print "QUANTITY: %s" % error_table[service][id]['value']
            print "TEXT: %s" % error_table[service][id]['content']
            print 
